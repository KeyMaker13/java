package currency;

public class Dime extends Currency {
	
	public Dime (){
		super(10, "Dime", "US");
	}

}
