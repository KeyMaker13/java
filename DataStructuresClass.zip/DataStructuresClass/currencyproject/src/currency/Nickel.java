package currency;

public class Nickel extends Currency {
	public Nickel (){
		super(5,"Nickel", "US");
	}

}
