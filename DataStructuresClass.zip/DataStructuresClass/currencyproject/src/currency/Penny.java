package currency;

public class Penny extends Currency{
	
	public Penny ()
	{
		super(1,"Penny", "US");
	}

}
