package currency;

public class Quarter extends Currency {
	
	public Quarter()
	{
		super( 25, "Quarter", "US");
	}
	public Quarter (int v, String n, String cc)
	{
		super(v,n,cc);
	}

}
