package collections;

import java.util.Random;

public class ArrayTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Create an Integer array with 10 elements

		// print array element one per line

		// Find the largest value in myArray
	}

}
