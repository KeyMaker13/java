package sets.linkedset;

public class LinkedOrderedSet<T> extends LinkedSet<T> {
  // need to implement the class
  public void add (T element){
  }
}
