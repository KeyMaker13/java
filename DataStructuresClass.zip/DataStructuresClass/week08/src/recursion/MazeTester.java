package recursion;

public class MazeTester {

	public static void main(String[] args) {
		Maze maze1 = new Maze("maze1.txt");
        System.out.println("maze1 = " + maze1);
        
		/*Maze maze2 = new Maze("maze2.txt");
        System.out.println("maze2 = " + maze2);*/
      
	}
}
