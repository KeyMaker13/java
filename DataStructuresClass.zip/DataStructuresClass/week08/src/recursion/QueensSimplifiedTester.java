package recursion;

public class QueensSimplifiedTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		QueensSimplified q1 = new QueensSimplified(4);
		System.out.println("q1 = " + q1.boardToString());
//		Queens q2 = new Queens(1);
//		System.out.println("q2 = " + q2.boardToString());
	}
}
