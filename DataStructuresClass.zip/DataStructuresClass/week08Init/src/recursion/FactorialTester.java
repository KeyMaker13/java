package recursion;

public class FactorialTester {

	// to be implemented
	public static void main(String[] args) {
		int f = FactorialTester.factorial(5);
		System.out.println("5! = " + f);

	}

	public static int factorial(int n) {
		return 0;
	}

}
