package recursion;

public class QueensTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Queens q1 = new Queens(4);	
	//Queens q2 = new Queens(1);
		Queens q3 = new Queens(8);
	}

}
