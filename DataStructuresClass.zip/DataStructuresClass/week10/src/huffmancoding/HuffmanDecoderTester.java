package huffmancoding;

import java.io.*;

public class HuffmanDecoderTester {
   public static void main(String[] args) {

   }
}
