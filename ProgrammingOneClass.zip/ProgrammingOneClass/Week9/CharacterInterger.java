public class CharacterInterger{
  public static void main(String[] args){
    for(int i=32; i<=126; i++){
      char c = (char) i;
      System.out.println(" i= " + i + " c= " + c);
    }
  }
}