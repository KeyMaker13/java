package pr2;

public interface TemperatureConstants {
 final static int DATA_SIZE = 10;
 final static int UNKNOWN_TEMP = Integer.MIN_VALUE;

}
