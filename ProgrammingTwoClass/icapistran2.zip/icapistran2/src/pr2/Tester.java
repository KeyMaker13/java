package pr2;

import java.util.ArrayList;

public class Tester
{
	public static void main(String[] args)
	{
		TemperaturePredictionList testList = new TemperaturePredictionList();
		testList.addFromDescriptor("Mar 16 62 85 62 82 62 80 62 81 63 82 58 87 54 84 50 82 53 78");
		testList.addFromDescriptor("Mar 17 62 83 61 80 61 79 61 85 59 86 58 87 57 83 55 81 57 80");
		
		System.out.println(testList);
	}

}
