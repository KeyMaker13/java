package simpleproject;

public class ComputeArea {
	public static void main(String[] args) {
	    System.out.println("This program was written by IVAN CAPISTRAN"); 
		int radius = 4;
	     double area = Math.PI * Math.pow(radius, 2);
	     System.out.println("A circle of radius " + radius + " has area " + area);
	  }

}
