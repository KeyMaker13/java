/**
 *  @author Lewis and Chase
 *
 *  Driver to run a demonstration of a stack with a graphical 
 *  user interface.
 */

public class StackDemo
{
  public static void main(String[] args)
  {
    StackGUI newDemo = new StackGUI();
    newDemo.display();
  }
}
