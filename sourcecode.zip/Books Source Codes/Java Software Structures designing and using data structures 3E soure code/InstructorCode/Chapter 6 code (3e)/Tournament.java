/** * Tournament is a driver for a program that demonstrates first round of 
 * tournament team match-ups using an ordered list.
 *
 * @author Dr. Lewis
 * @author Dr. Chase
 * @version 1.0, 08/12/08
 */import java.io.*;public class Tournament    {   /**    * Determines and prints the tournament organization.    */   public static void main (String[] args ) throws IOException   {	   TournamentMaker temp = new TournamentMaker();	   temp.make();   } }
