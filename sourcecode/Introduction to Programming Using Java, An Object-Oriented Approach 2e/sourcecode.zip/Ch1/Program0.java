
public class Program0 {
    public static void main(String[] arg) {
	System.out.println("Welcome To Java!");
    }
}
