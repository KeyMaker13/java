/*
 * Program1: Announces my first Java program experience and my intent to continue
 */
public class Program1 {
    public static void main(String[] arg) {
	System.out.println("This is my first Java program");
	System.out.println(" but it won't be my last.");
    }
}
