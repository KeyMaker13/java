interface CounterObserver {
	public void counterHasChanged(CounterMultiObserver ctr);
}