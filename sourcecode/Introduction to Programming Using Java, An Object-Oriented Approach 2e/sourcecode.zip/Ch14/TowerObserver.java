interface TowerObserver {
	public void towerHasChanged(TowerThread tower);
}