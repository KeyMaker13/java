
class TCPException extends Exception  {
	TCPException() {
		super();
	}

	TCPException(String s) {
		super(s);
	}
}
