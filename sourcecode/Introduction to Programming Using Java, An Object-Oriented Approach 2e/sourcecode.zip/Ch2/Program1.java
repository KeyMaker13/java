public class Program1 {
    public static void main(String[] arg) {
	String greeting;
	String bigGreeting;
	greeting = "Yo, World";
	bigGreeting = greeting.toUpperCase();
	System.out.println(greeting);
	System.out.println(bigGreeting);
    }
}
