public class Program2 {
    public static void main(String[] arg) {
	String greeting = "Yo, World";
	String bigGreeting = greeting.toUpperCase();
	System.out.println(greeting);
	System.out.println(bigGreeting);
    }
}
