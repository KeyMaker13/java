public class Program2a {
    public static void main(String[] arg) {
	int num1 = 11;
	int num2 = 4;
	int num3 = 21;
	int sum;
	int average;
	sum = num1 + num2 + num3;
	average = sum / 3;
	System.out.print("The average is ");
	System.out.print(average);
    }
}
