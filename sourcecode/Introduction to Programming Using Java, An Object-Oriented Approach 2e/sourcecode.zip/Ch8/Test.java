public  class  Test  {
	public  static  void  main(String  args[])  {
		int x  =  5,  y  =  0;
		TestHelper.verify(x==y,"Just  a  test");  
    }
}
